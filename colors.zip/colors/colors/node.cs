﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace colors
{
    public class node
    {
       public Square[,] matrix;
       public int line;
        public int val;
        public node(Square[,] m,int v, int l)
        {
            matrix = m;
            val = v;
            line = l;
        }
    }
}
