﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace colors
{
    public class Square
    {
       public string color;
       public int value;
       public Square(string c,int v)
        {
            color = c;
            value = v;
        }

    }
}
