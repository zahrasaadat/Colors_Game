﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace colors
{
    public partial class Form1 : Form
    {
       static Square[,] GameBoard = new Square[8, 8];
        int max_depht =1;
        node ChosenNode = new node(null,0, 0);
        public Form1()
        {
            InitializeComponent();
        }

        public Square[,] ALPHA_BETA_SEARCH(Square[,] state)
        {
            int firstAlpha=-10000;
            int firstBeta = 10000;
            node crnt = new node(state,0, 0);
            int val = MAX_VALUE(crnt, firstAlpha, firstBeta);
          
            return ChosenNode.matrix;
        }

        public int MAX_VALUE(node current_node , int Alpha, int Beta)
        {
            if (current_node.line == max_depht)
                return Eval( current_node.matrix);
            List<node> successors = new List<node>();
            successors = Make_Successor(current_node, "yellow");
            int v = -10000;
            if(current_node.line==0)
                 ChosenNode = successors[0];
            for (int i=0;i< successors.Count-1;i++)
            {
                
                node new_n = copy_node(successors[i]);
                v = Maximum(v, MIN_VALUE(new_n, Alpha, Beta));
                successors[i].val = v;
                if (v >= Beta)
                    return v;
                Alpha = Maximum(v, Alpha);
            }
            if (current_node.line == 0)
            {
                for(int r = 0; r < successors.Count - 1; r++)
                {
                    if (ChosenNode.val < successors[r].val)
                    {
                        ChosenNode = successors[r];
                    }
                }
            }
            return v;
        }

        public int MIN_VALUE(node current_node, int Alpha, int Beta)
        {
            if (current_node.line == max_depht )
                return Eval(current_node.matrix);
            List<node> successors = new List<node>();
            successors = Make_Successor(current_node, "pink");
            int v = 10000;
            foreach (node n in successors)
            {
                v = Minimum (v, MAX_VALUE(n, Alpha, Beta));
                n.val = v;
                if (v<= Alpha)
                    return v;
                Beta =Minimum (v, Beta);
            }
            return v;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
       
            Graphics g = e.Graphics;
            Rectangle rect = default(Rectangle);
            g.PageUnit = GraphicsUnit.Pixel;
          
            for (int i = 0; i <= 7; i++)
            {
                for (int j = 0; j <= 7; j++)
                {
                    rect = new Rectangle(j * 60, i * 60, 60, 60);
                    if (GameBoard[i, j].color=="pink")
                    {
                       g.FillRectangle(Brushes.DeepPink, rect);
                         g.DrawString(Convert.ToString( GameBoard[i, j].value), new Font("Hobo Std",12), Brushes.MidnightBlue, j * 60 + 25, i * 60 + 25);

                    }
                    if (GameBoard[i, j].color == "white")
                    {
                        g.FillRectangle(Brushes.SeaShell, rect);
                    }
                    if (GameBoard[i, j].color == "yellow")
                    {
                      
                        g.FillRectangle(Brushes.Yellow, rect);
                        g.DrawString(Convert.ToString(GameBoard[i, j].value), new Font("Hobo Std", 12), Brushes.MidnightBlue, j * 60 + 25, i * 60 + 25);
                    }

                }
            }
            for (int i = 0; i <= 7; i++)
            {
                g.DrawLine(Pens.DarkBlue, 0, i * 60, 480, i * 60);
                g.DrawLine(Pens.DarkBlue, i * 60, i, i * 60, 480);
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 8; i++)
            {
               for(int j = 0; j < 8; j++)
                {
                    Square sqr = new Square("white", 0);
                   GameBoard[i, j] = sqr;
                  
                }
            }
            GameBoard[0, 0].color = "pink";
            GameBoard[0, 7].color = "yellow";
            GameBoard[7, 7].color = "pink";
            GameBoard[7, 0].color = "yellow";
            GameBoard[0, 0].value =5;
            GameBoard[0, 7].value =5;
            GameBoard[7, 7].value = 5;
            GameBoard[7, 0].value = 5;
        }

        public bool IsColored(Square box)
        {
            if (box.color == "pink" || box.color == "yellow")
            {
                return true;
            }
            else return false;
        }

        public List<int> Possible_Acts(Square[,] current)
        {
            List<int> possibles = new List<int>();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (current[i, j].color == "white") { 
                    List<int> arround = Neibours(i, j);
                    for (int k = 0; k < arround.Count - 1; k += 2)
                    {
                        if (IsColored(current[arround[k], arround[k + 1]]))
                        {
                            possibles.Add(i);
                            possibles.Add(j);
                            break;
                        }


                    }
                }
                }
            }
            return possibles;
        }

        public Square[,] Do_Act(int i, int j, Square[,] current, string Min_or_Max_color)
        {
            Square[,] current2 = copy_matrix(current);
            current2[i, j].color = Min_or_Max_color;
            current2[i, j].value = 1;
            List<int> arround = Neibours(i, j);
            for (int k = 0; k < arround.Count-1; k += 2)
            {
                if (IsColored(current[arround[ k],arround[ k + 1]])) {
                    current2[arround[ k],arround[ k + 1]].color = Min_or_Max_color;
                    current2[arround[ k],arround[ k + 1]].value++;
                  }
                    
            }
            return current2;
        }

        public bool Is_Yours(Square[,] current ,int i, int j)
        {
            List<int> arround = Neibours(i, j);
            int c = 0;
            for (int k = 0; k < arround.Count-1; k += 2)
            {
                if (IsColored(current[arround[k], arround[k + 1]]))
                    c++;
            }
            if (c == arround.Count / 2 )
                return true;
            else
                return false;

        }

        public List<int> Neibours(int i, int j)
        {
            List<int> nbrs = new List<int>(); 
            if(i==0 & j == 0)
            {
                nbrs.Add(0);
                nbrs.Add(1);
                nbrs.Add(1);
                nbrs.Add(0);
                nbrs.Add(1);
                nbrs.Add(1);
                return nbrs;
            }
            if (i == 0 & j == 7)
            {
                nbrs.Add(0);
                nbrs.Add(6);
                nbrs.Add(1);
                nbrs.Add(6);
                nbrs.Add(1);
                nbrs.Add(7);
                return nbrs;
            }
            if (i == 7 & j == 0)
            {
                nbrs.Add(7);
                nbrs.Add(1);
                nbrs.Add(6);
                nbrs.Add(0);
                nbrs.Add(6);
                nbrs.Add(1);
                return nbrs;
            }
            if (i == 7 & j ==7 )
            {
                nbrs.Add(7);
                nbrs.Add(6);
                nbrs.Add(6);
                nbrs.Add(7);
                nbrs.Add(6);
                nbrs.Add(6);
                return nbrs;
            }
            if (i == 0)
            {
                nbrs.Add(0);
                nbrs.Add(j - 1);
                nbrs.Add(0);
                nbrs.Add(j + 1);
                nbrs.Add(1);
                nbrs.Add(j - 1);
                nbrs.Add(1);
                nbrs.Add(j + 1);
                nbrs.Add(1);
                nbrs.Add(j);

            }
           else if (i == 7)
            {
                nbrs.Add(7);
                nbrs.Add(j - 1);
                nbrs.Add(7);
                nbrs.Add(j + 1);
                nbrs.Add(6);
                nbrs.Add(j - 1);
                nbrs.Add(6);
                nbrs.Add(j + 1);
                nbrs.Add(6);
                nbrs.Add(j);

            }
           else if (j == 0)
            {
                nbrs.Add(i);
                nbrs.Add( 1);
                nbrs.Add(i-1);
                nbrs.Add(0);
                nbrs.Add(i-1);
                nbrs.Add( 1);
                nbrs.Add(i+1);
                nbrs.Add(0);
                nbrs.Add(i+1);
                nbrs.Add(1);

            }
          else  if (j == 7)
            {
                nbrs.Add(i);
                nbrs.Add(6);
                nbrs.Add(i - 1);
                nbrs.Add(7);
                nbrs.Add(i - 1);
                nbrs.Add(6);
                nbrs.Add(i + 1);
                nbrs.Add(7);
                nbrs.Add(i + 1);
                nbrs.Add(6);

            }
            else
            {
                nbrs.Add(i);
                nbrs.Add(j+1);
                nbrs.Add(i);
                nbrs.Add(j - 1);
                nbrs.Add(i - 1);
                nbrs.Add(j-1);
                nbrs.Add(i - 1);
                nbrs.Add(j);
                nbrs.Add(i - 1);
                nbrs.Add(j+1);
                nbrs.Add(i + 1);
                nbrs.Add(j-1);
                nbrs.Add(i + 1);
                nbrs.Add(j);
                nbrs.Add(i + 1);
                nbrs.Add(j+1);
            }
            return nbrs;
        }

        public int Eval(Square[,] current)
        {
            int max_count = 0;
            int min_count = 0;
            for(int k = 0; k < 8; k ++)
            {
                for(int t = 0; t < 8; t++)
                {
                    if (current[k, t].color == "pink")
                    {
                        if (Is_Yours(current, k, t))
                            min_count++;

                    }
                    if (current[k, t].color == "yellow")
                    {
                        if (Is_Yours(current, k, t))
                            max_count++;

                    }
                }
         
            }
            int val = 8 * (max_count - min_count) + scores(current)[1] - scores(current)[0];
            return val;
        }

        public Square[,] copy_matrix(Square[,] privios)
        {
            Square[,] new_matrix=new Square[8,8];
            for (int t = 0; t < 8; t++)
            {
                for (int r = 0; r < 8; r++)
                {
                    Square a = new Square("white", 0);
                    new_matrix[t, r] = a;
                }
            }
            for (int t = 0; t < 8; t++)
            {
                for(int r = 0; r < 8; r++)
                {
                    new_matrix[t, r].color = privios[t, r].color;
                    new_matrix[t, r].value = privios[t, r].value;
                }
            }
            return new_matrix;
        }

        public node copy_node(node p)
        {
            Square[,] m = p.matrix;
            int l = p.line;
            int v = p.val;
            node n = new node(m,v, l);
            return n;
        }

        public List<node> Make_Successor(node father, string turn)
        {
            List<int> choices = Possible_Acts(father.matrix);
            List<node> successor = new List<node>();
            Square[,] new_state, dad;
            for(int c = 0; c < choices.Count-1; c += 2)
            {
                dad = copy_matrix(father.matrix);
                new_state=Do_Act(choices[c], choices[c + 1], dad, turn);
                node new_node = new node(new_state,0,father.line + 1);
                successor.Add(new_node);
            }
            return successor;

        }

        public bool IsValid(int i, int j, Square[,] current)
        {
            List<int> arround = Neibours(i, j);
            if (current[i, j].color == "white")
            {
                for (int k = 0; k < arround.Count - 1; k += 2)
                {
                    if (IsColored(current[arround[k], arround[k + 1]]))
                        return true;
                }
            }
            return false;
        }

        public int Maximum(int z, int t)
        {
            if (z > t)
                return z;
            return t;
        }

        public int Minimum(int z, int t)
        {
            if (z < t)
                return z;
            return t;
        }

        public int[] scores(Square[,] stt)
        {
            int[] scr = { 0, 0 };
            for(int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (stt[i, j].color == "pink")
                        scr[0] += stt[i, j].value;
                    if (stt[i, j].color == "yellow")
                        scr[1] += stt[i, j].value;
                }
               
            }
            return scr;
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            radioButton1.Visible = false;
            radioButton2.Visible = false;
            radioButton3.Visible = false;
            label1.Visible = false;
            int x = e.X/60;
            int y = e.Y/60;
            if (IsValid(y,x, GameBoard))
            {
                GameBoard = Do_Act(y,x, GameBoard, "pink");
                pictureBox1.Refresh();
                label4.Text = Convert.ToString(scores(GameBoard)[0]);
                label5.Text = Convert.ToString(scores(GameBoard)[1]);
                Thread.Sleep(300);
                GameBoard = ALPHA_BETA_SEARCH(GameBoard);
                pictureBox1.Refresh();
            }
            label4.Text=Convert.ToString( scores(GameBoard)[0]);
            label5.Text = Convert.ToString(scores(GameBoard)[1]);
            if (Possible_Acts(GameBoard).Count == 0)
            {
                if (Convert.ToInt32(label4.Text) > Convert.ToInt32(label5.Text))
                    MessageBox.Show("!!!شما بردید:D");
                else
                    MessageBox.Show("!!!شما باختید:(");
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            max_depht = 3;
            

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            max_depht = 2;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            max_depht = 4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            radioButton1.Visible = true;
            radioButton2.Visible = true;
            radioButton3.Visible = true;
            label1.Visible = true;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Square sqr = new Square("white", 0);
                    GameBoard[i, j] = sqr;

                }
            }
            GameBoard[0, 0].color = "pink";
            GameBoard[0, 7].color = "yellow";
            GameBoard[7, 7].color = "pink";
            GameBoard[7, 0].color = "yellow";
            GameBoard[0, 0].value = 5;
            GameBoard[0, 7].value = 5;
            GameBoard[7, 7].value = 5;
            GameBoard[7, 0].value = 5;
            pictureBox1.Refresh();
        }
    }
}
